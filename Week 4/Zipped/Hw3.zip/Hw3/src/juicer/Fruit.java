package juicer;

import copy.Copyable;

// TODO:  Hw3 Part 1: Add the Fruit class here