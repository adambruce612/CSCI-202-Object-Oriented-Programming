package copy;

public interface Copyable
{
    Object copy();
}
